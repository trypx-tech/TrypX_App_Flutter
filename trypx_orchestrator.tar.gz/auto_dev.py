"""
TrypX Flutter - Two-LLM Autonomous Build Orchestrator
=====================================================
BRAIN  : Claude Opus 4.8  (via Genspark LLM proxy, HTTP)  -> plans + VERIFIES
HANDS  : Gemini CLI        (gemini -y --skip-trust -p ...) -> writes/edits code
JUDGE  : flutter analyze + flutter test                    -> objective pass/fail

Two DIFFERENT models: Gemini writes the code, Opus (a different model) independently
reviews it against the spec + the REAL flutter output. Opus cannot rubber-stamp,
because the flutter exit code is objective ground truth.

Reads ordered tasks from ./tasks/F-00.md, F-01.md, ...
Per task:
  1) OPUS turns the task spec into precise doer-instructions.
  2) GEMINI writes the files.
  3) flutter analyze + flutter test  (ground truth).
  4) OPUS verifies: sees task + git diff + flutter output, returns a strict verdict
     PASS / FIX / NEEDS-DECISION. On FIX, Opus writes the fix and we loop (max 3).
  5) PASS -> git commit -> next task. Otherwise STOP and escalate to Gopal.

Requires: env var GSK_API_KEY. Python 3.8+. No third-party packages.

Run:  python auto_dev.py            (all pending tasks)
      python auto_dev.py F-01       (one task)
      python auto_dev.py --dry-run  (plan only, no changes)
"""

import json
import os
import re
import subprocess
import sys
import time
import urllib.request
import urllib.error
from pathlib import Path

# ------------------------------------------------------------------ CONFIG
PROJECT_DIR = Path(r"E:\TrypX_App_Flutter\trypx")   # set by/after F-00
HERE        = Path(__file__).parent
TASKS_DIR   = HERE / "tasks"
REF_DIR     = HERE / "reference"
OPUS_SYS    = HERE / "OPUS_SYSTEM.md"
STATE_FILE  = HERE / "state.txt"
LOG_FILE    = HERE / "run.log"

OPUS_MODEL  = "claude-opus-4-8"
PROXY_URL   = "https://www.genspark.ai/api/llm_proxy/v1/chat/completions"
API_KEY     = os.environ.get("GSK_API_KEY", "")

MAX_FIX_ATTEMPTS = 3
GEMINI_TIMEOUT   = 900
FLUTTER_TIMEOUT  = 600
OPUS_TIMEOUT     = 180

# A task file whose FIRST body line starts with this is human-only; never automate.
DECISION_MARKERS = ["TASK-REQUIRES-HUMAN"]
# If Gemini or Opus report touching these, STOP for human review (invariant 21 etc.)
FORBIDDEN_TOUCH = [
    "firebase_options.dart", "google-services.json", "GoogleService-Info.plist",
    "api_key", "apikey", "secret",
]

# ------------------------------------------------------------------ IO HELPERS
def log(msg):
    line = f"[{time.strftime('%H:%M:%S')}] {msg}"
    print(line)
    with open(LOG_FILE, "a", encoding="utf-8") as f:
        f.write(line + "\n")

def run(cmd, cwd, timeout):
    try:
        r = subprocess.run(cmd, cwd=str(cwd), capture_output=True, text=True, timeout=timeout)
        return r.returncode, (r.stdout or "") + (r.stderr or "")
    except subprocess.TimeoutExpired:
        return 124, f"TIMEOUT after {timeout}s: {' '.join(cmd)}"
    except FileNotFoundError as e:
        return 127, f"Command not found: {e}"

# ------------------------------------------------------------------ OPUS (BRAIN)
def opus(messages, max_tokens=4000):
    """Call Claude Opus via the Genspark proxy. messages = [{role, content}, ...]."""
    if not API_KEY:
        raise RuntimeError("GSK_API_KEY env var is not set.")
    body = json.dumps({"model": OPUS_MODEL, "messages": messages,
                       "max_tokens": max_tokens}).encode()
    req = urllib.request.Request(
        PROXY_URL, data=body,
        headers={"Authorization": f"Bearer {API_KEY}", "Content-Type": "application/json"})
    last = None
    for attempt in range(3):
        try:
            with urllib.request.urlopen(req, timeout=OPUS_TIMEOUT) as resp:
                data = json.load(resp)
            return data["choices"][0]["message"]["content"]
        except (urllib.error.URLError, KeyError, json.JSONDecodeError) as e:
            last = e
            time.sleep(2 * (attempt + 1))
    raise RuntimeError(f"Opus call failed after retries: {last}")

def opus_system_prompt():
    base = OPUS_SYS.read_text(encoding="utf-8") if OPUS_SYS.exists() else ""
    inv = (REF_DIR / "INVARIANTS.md")
    if inv.exists():
        base += "\n\n## TrypX INVARIANTS (law)\n" + inv.read_text(encoding="utf-8")
    return base

# ------------------------------------------------------------------ GEMINI (HANDS)
def gemini(prompt):
    log("  -> Gemini (doer) writing code...")
    _, out = run(["gemini", "-y", "--skip-trust", "-p", prompt],
                 cwd=PROJECT_DIR, timeout=GEMINI_TIMEOUT)
    return out

# ------------------------------------------------------------------ JUDGE (FLUTTER)
def verify_flutter():
    a_code, a_out = run(["flutter", "analyze"], cwd=PROJECT_DIR, timeout=FLUTTER_TIMEOUT)
    if a_code != 0:
        return False, "FLUTTER ANALYZE FAILED:\n" + a_out
    t_code, t_out = run(["flutter", "test"], cwd=PROJECT_DIR, timeout=FLUTTER_TIMEOUT)
    if t_code != 0:
        return False, "FLUTTER TEST FAILED:\n" + t_out
    return True, "FLUTTER OK:\n" + a_out + "\n" + t_out

def git_diff():
    _, out = run(["git", "--no-pager", "diff", "--stat", "HEAD"], cwd=PROJECT_DIR, timeout=60)
    _, out2 = run(["git", "--no-pager", "diff", "HEAD"], cwd=PROJECT_DIR, timeout=60)
    return (out + "\n" + out2)[:8000]

def git_commit(task_id, summary):
    run(["git", "add", "-A"], cwd=PROJECT_DIR, timeout=60)
    run(["git", "commit", "-m", f"{task_id}: {summary}"], cwd=PROJECT_DIR, timeout=60)
    log(f"  committed: {task_id}: {summary}")

# ------------------------------------------------------------------ GUARDS / STATE
def guard_forbidden(text):
    low = text.lower()
    return next((b for b in FORBIDDEN_TOUCH if b.lower() in low), None)

def load_state(): return STATE_FILE.read_text().strip() if STATE_FILE.exists() else ""
def save_state(t): STATE_FILE.write_text(t)
def task_files(): return sorted(TASKS_DIR.glob("F-*.md"))

def reference_context(task_body):
    """Attach any reference files the task explicitly names (keeps prompts lean)."""
    chunks = []
    for ref in REF_DIR.glob("*.md"):
        if ref.name in task_body:
            chunks.append(f"--- reference/{ref.name} ---\n{ref.read_text(encoding='utf-8')}")
    return "\n\n".join(chunks)

# ------------------------------------------------------------------ CORE
def parse_verdict(text):
    """Opus verifier must reply with a line starting VERDICT: PASS|FIX|NEEDS-DECISION."""
    m = re.search(r"(?im)^\s*VERDICT:\s*(PASS|FIX|NEEDS-DECISION)\b", text)
    return m.group(1).upper() if m else "FIX"

def do_task(path, dry_run=False):
    task_id = path.stem
    body = path.read_text(encoding="utf-8")
    sm = re.search(r"SUMMARY:\s*(.+)", body)
    summary = sm.group(1).strip() if sm else task_id

    for marker in DECISION_MARKERS:
        if re.search(rf"(?m)^\s*{re.escape(marker)}\b", body):
            log(f"STOP. {task_id} is a human-only task ({marker}).")
            return "STOP"

    log(f"=== {task_id}: {summary} ===")
    if dry_run:
        log("  (dry-run) would: Opus plan -> Gemini code -> flutter -> Opus verify.")
        return "DRY"

    sys_prompt = opus_system_prompt()
    refs = reference_context(body)

    # 1) OPUS PLANS the doer instructions
    log("  -> Opus (orchestrator) planning doer instructions...")
    plan = opus([
        {"role": "system", "content": sys_prompt},
        {"role": "user", "content":
            f"TASK {task_id}.\n\nTask spec:\n{body}\n\n"
            + (f"Reference material:\n{refs}\n\n" if refs else "")
            + "Write precise, literal instructions for the Gemini coding agent to perform "
              "ONLY this task. Include exact file paths and exact file contents. Do not add "
              "scope. Output only the instructions for Gemini."},
    ])
    bad = guard_forbidden(plan)
    if bad:
        log(f"STOP. Opus plan references forbidden area ('{bad}').")
        return "STOP"

    # 2) GEMINI EXECUTES
    gem_out = gemini(plan)
    bad = guard_forbidden(gem_out)
    if bad:
        log(f"STOP. Gemini output references forbidden area ('{bad}').")
        return "STOP"

    # 3+4) JUDGE then OPUS VERIFY, with fix loop
    for attempt in range(1, MAX_FIX_ATTEMPTS + 1):
        ok, flutter_logs = verify_flutter()
        diff = git_diff()
        log(f"  -> Opus verifying (attempt {attempt}, flutter_ok={ok})...")
        verdict_text = opus([
            {"role": "system", "content": sys_prompt},
            {"role": "user", "content":
                f"You are VERIFYING task {task_id}.\n\nTask spec:\n{body}\n\n"
                f"Code diff since last commit:\n{diff}\n\n"
                f"Flutter ground-truth result:\n{flutter_logs[:6000]}\n\n"
                "Rules: A task PASSES only if flutter analyze AND tests pass AND the code "
                "matches the spec AND no TrypX invariant is violated. If flutter failed, "
                "you must NOT pass. Never approve edits to tests that merely force them green.\n"
                "Reply with a first line exactly like `VERDICT: PASS` or `VERDICT: FIX` or "
                "`VERDICT: NEEDS-DECISION`. If FIX, follow with literal corrected instructions "
                "for Gemini. If NEEDS-DECISION, follow with the question for Gopal."},
        ])
        verdict = parse_verdict(verdict_text)

        if verdict == "PASS" and ok:
            log(f"  PASS (Opus verified + flutter green) on attempt {attempt}.")
            git_commit(task_id, summary)
            save_state(task_id)
            return "DONE"
        if verdict == "NEEDS-DECISION":
            log(f"STOP. Opus raised NEEDS-DECISION:\n{verdict_text}")
            return "STOP"
        if verdict == "PASS" and not ok:
            log("  Opus said PASS but flutter is RED -> overriding to FIX (ground truth wins).")

        if attempt == MAX_FIX_ATTEMPTS:
            break
        log(f"  FIX attempt {attempt}/{MAX_FIX_ATTEMPTS}. Opus wrote a fix; sending to Gemini.")
        fix_instr = re.sub(r"(?is)^.*?VERDICT:\s*FIX\b", "", verdict_text).strip() or (
            f"Fix the code so flutter analyze and test pass. Errors:\n{flutter_logs[:5000]}")
        gem_out = gemini(
            "Do NOT change versions, Firebase config, secrets. Do NOT edit tests to force "
            f"them green. Apply exactly this fix for {task_id}:\n\n{fix_instr}")
        bad = guard_forbidden(gem_out)
        if bad:
            log(f"STOP. Fix references forbidden area ('{bad}').")
            return "STOP"

    log(f"STOP. {task_id} still failing after {MAX_FIX_ATTEMPTS} attempts. Human needed.")
    return "BLOCKED"

def main():
    args = sys.argv[1:]
    dry = "--dry-run" in args
    single = next((a for a in args if a.startswith("F-")), None)

    if not API_KEY and not dry:
        log("ERROR: GSK_API_KEY not set. Run setx GSK_API_KEY \"...\" and reopen PowerShell.")
        return
    if not PROJECT_DIR.exists() and single != "F-00" and not dry:
        log(f"NOTE: {PROJECT_DIR} missing. Run F-00 first or fix PROJECT_DIR.")

    files = task_files()
    if not files:
        log("No task files in ./tasks/.")
        return
    if single:
        match = [f for f in files if f.stem == single]
        if not match:
            log(f"Task {single} not found.")
            return
        do_task(match[0], dry)
        return

    last = load_state()
    started = (last == "")
    for f in files:
        if not started:
            if f.stem == last:
                started = True
            continue
        if do_task(f, dry) in ("STOP", "BLOCKED"):
            log("Loop halted. Resolve, then re-run `python auto_dev.py`.")
            break

if __name__ == "__main__":
    main()
