# TrypX Flutter — Two-LLM Autonomous Build System

## The three roles
- **Brain (orchestrator + verifier):** Claude Opus 4.8 via the Genspark LLM proxy (HTTP).
  Plans the doer's instructions AND reviews the result. A *different* model from the doer.
- **Hands (doer):** Gemini CLI — writes/edits the Flutter code.
- **Judge (ground truth):** `flutter analyze` + `flutter test`. Opus can never pass a red build.

## Files
```
auto_dev.py        the loop (Opus plan -> Gemini code -> flutter -> Opus verify)
OPUS_SYSTEM.md     orchestrator rulebook (loaded as Opus's system prompt)
GEMINI.md          doer rulebook (Gemini CLI auto-loads it)
tasks/F-00.md ...   ordered build tasks (one task = one commit)
reference/         knowledge ported from Sandeep's Kotlin repo:
    INVARIANTS.md            the 21 laws (verbatim)
    DATA_MODEL.md            enums, entities, pure business rules
    DESIGN_TOKENS.md         exact colors / type / spacing
    COMPONENT_CATALOGUE.md   ~25 design-system widgets
    AI_TASK_CATALOGUE.md     the 18 AI tasks + metadata
    SCREENS.md               25 screens + onboarding/reviewer flow
state.txt          auto-written: last completed task (resume point)
run.log            auto-written: full run log
```

## One-time setup (PowerShell)
```powershell
setx GSK_API_KEY "<your full gsk key>"     # then close & reopen PowerShell
$env:GSK_API_KEY                            # confirm it prints
```
Put this whole folder at E:\TrypX_App_Flutter\ (so GEMINI.md is beside your project).

## First run — DO F-00 MANUALLY (see it work once)
```powershell
cd E:\TrypX_App_Flutter
gemini -y --skip-trust -p (Get-Content -Raw .\tasks\F-00.md)
cd trypx
flutter analyze        # expect: No issues found!
```
Then set PROJECT_DIR in auto_dev.py if the app landed somewhere other than
E:\TrypX_App_Flutter\trypx.

## Then run the loop
```powershell
cd E:\TrypX_App_Flutter
python auto_dev.py --dry-run     # shows the plan, changes nothing
python auto_dev.py F-01          # run one task autonomously
python auto_dev.py               # run all remaining tasks in order
```

## Hard safety rules (enforced in code)
- PASS only if flutter analyze AND test pass AND Opus verifies spec + invariants.
- Ground truth wins: if Opus says PASS but flutter is red, it's forced to FIX.
- Max 3 fix attempts per task, then STOP for Gopal.
- Never changes versions / Firebase config / secrets (auto-STOP). (invariant 21)
- Never edits tests to force green. Never git push (you review & push).
- A task file starting with `TASK-REQUIRES-HUMAN` is never automated.

## Push to GitHub (manual, after review)
Commits are local. When happy:
```powershell
cd E:\TrypX_App_Flutter\trypx
git remote add origin https://github.com/trypx-tech/TrypX_Flutter.git
git push -u origin master
```
(Create the TrypX_Flutter repo under the trypx-tech org first.)
```
```
